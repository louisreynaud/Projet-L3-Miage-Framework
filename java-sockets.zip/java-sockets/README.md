# Java Sockets

## Objectives

- Create a simple chat application that uses the Java Sockets API;
- Put Java knowledge to practice;

## Planned Iterations

- Enable client communicate with server;
- Enable client to send a text file to server;
- Implement multi-clients functionality;
- Enable clients to communicate with each other;
