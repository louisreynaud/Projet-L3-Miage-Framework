package csi.grp6;

public class Program {
	public static void main(String[] args) {
		Application.setSystemLookAndFeel();
		Application.run();
	}
}
